package com.example.yamltoswagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YamlToSwaggerApplication {

    public static void main(String[] args) {
        SpringApplication.run(YamlToSwaggerApplication.class, args);
    }

}
