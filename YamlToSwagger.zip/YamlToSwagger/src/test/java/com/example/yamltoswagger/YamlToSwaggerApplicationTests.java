package com.example.yamltoswagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YamlToSwaggerApplicationTests {

    @Test
    void contextLoads() {
    }

}
